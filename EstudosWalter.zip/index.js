

const express = require("express")

const server = express()
server.use(express.json())
server.use(express.urlencoded({ extended: true }))

server.get("/", Root)
server.get("/ola", Ola)
server.get("/status", Status)
server.post("/salva_arquivo", SalvaArquivo)

server.listen(8080, InitMessage)


///////////////////////////////////////////
// ----------FUNÇÕES-------------

function Root(req, res) {
  return res.send("Agora o endpoint / funcionou!")
}

function Ola(req, res) {
  return res.send("Hello World")
}

function Status(req, res) {
  const obj = {
    mensagem: "Servidor esta online",
    timestamp: Date.now()
  }
  console.log("Status Acionado")
  return res.json(obj)
}

function SalvaArquivo(req, res) {
  console.log("Salvando Arquivo ...")
  const corpomensagem = req.body
  console.log(corpomensagem)
  return res.send("Arquivo Salvo")
}

function InitMessage() {
  console.log("Servidor Inicializado")
}
