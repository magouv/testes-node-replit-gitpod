const v1 = 10.0
const v2 = "Zezinho"
const str1 = `Olá ${v2}, você tem R$ ${v1}.`

var dia = "21"
var mes = 2 * 4
const ano = 1971
const str2 = `Data de nascimento: ${dia}/${mes}/${ano}`
const str3 = `Data no formato americano: ${ano}-${mes}-${dia}`

console.log(str1)
console.log(str2)
console.log(str3)
